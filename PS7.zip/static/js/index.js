


// This will be the object that will contain the Vue attributes
// and be used to initialize it.
let app = {};

// Given an empty app object, initializes it filling its attributes,
// creates a Vue instance, and then initializes the Vue instance.
let init = (app) => {
    // **************************************************************************
    // ****************************** App Initialization Setup ******************************
    // **************************************************************************
    // This is the Vue data.

    app.data = {
        // Complete as you see fit.
        event_query: "",
        events: [], //Search results list
        completed_setting: "your_events",
        num_completed: 0,
    };    
    app.enumerate = (a) => {
        // This adds an _idx field to each element of the array.
        let k = 0;
        a.map((e) => {e._idx = k++;});
        return a;
    };    
    
    // ****************************** Load Events ******************************
    app.get_events = function (){
        console.log("loading events")
        // ****************************** Get Events According to Setting******************************
        axios.get(get_events_url, {params: {setting: app.data.completed_setting}}) //Query python backend (GET, passing query)
            .then(function(result){ //Using the result from python's "get_events_url",
                let result_events = result.data.results; //Initial event list result from python controller
                for(let i=0;i<result_events.length;i++){ 
                    let completion_time = result_events[i].completion_time !== null ?
                    new Date(result_events[i].completion_time).toLocaleString() :
                    result_events[i].completion_time
                    result_events[i] = { //
                        "id": result_events[i].id,
                        "title": result_events[i].title,
                        "user_email": result_events[i].user_email,
                        "due_time": new Date(result_events[i].due_time).toLocaleString(),
                        "start": new Date(result_events[i].start).toLocaleString(), 
                        "end": new Date(result_events[i].end).toLocaleString(), 
                        "description": result_events[i].description,
                        "completion_time": completion_time,
                    }
                }
                app.data.events = result_events;//result.data.results //Assign the list of results to the response
                console.log(result.data.results);
                app.drawCalendar();
                app.drawProductivityBar(app.data.events);
            })
            // ****************************** Get number of your completed events******************************
            axios.get(get_events_url, {params: {setting: "your_completed"}}) //Query python backend (GET, passing query)
            .then(function(result){ //Using the result from python's "get_events_url",
                let result_events = result.data.results; //Initial event list result from python controller
                app.data.num_completed = result_events.length;
            })
    }

    // ****************************** Set Completed Setting ******************************
    //Changes the setting for which events are listed according to which button is pressed.
    app.set_completed_setting = function (new_setting){
        app.data.completed_setting = new_setting; //Change completed_setting variable
        console.log("Set to", app.data.completed_setting);
        app.get_events(); //Reload meow listing
    }
    // ****************************** Set Completed ******************************
    app.set_completed = function (event){
        console.log(event.id)
        axios.post(set_completed_url, //
            {
                event_id: event.id
            }
            ).then(function(response){
                app.get_events();
            })
    }
        // ****************************** Get Productivity ******************************
        app.get_productivity = async function (date){
            // ****************************** Get productivity entry for given date ******************************
            
            let res = await axios.get(get_productivity_url, {params: {date: date}}); //Query python backend (GET, passing query)
            console.log(res.data.results)
            return res.data.results;
            // .then(function(result){
            //     console.log(result.data.results);
            //     return result.data.results;
            // })
        }
    app.calcProductivity = function(){
        setInterval(function(){
            let curTime = new Date();
            app.get_productivity(new Date()).then(res => {
                console.log(res)
                        document.getElementById("productivity-bar-heading").innerHTML = "Today's Productivity: " +  res*(24*60) + "%";
                    }
                )
            
            //drawProductivityBar(app.data.events);
          }, 1000);
    }
    app.drawCalendar = function (){
        let calendarEvents = app.data.events.slice(); //Get current list
        for(let i=0;i<calendarEvents.length;i++){
            calendarEvents[i] = {
                start: new Date(calendarEvents[i].start),
                end: new Date(calendarEvents[i].end),
                title: calendarEvents[i].title,
            }
        }
        
        //of calendar events
        // calendarEvents = calendarEvents.replaceAll('\'', '\"'); //Replace python quotes with JSON quotes
        // calendarEvents = calendarEvents.replaceAll('None', 'null'); //Replace Python None with JSON null
        // calendarEvents = JSON.parse(calendarEvents); //Convert python string to JSON
        // ******************** Draw Calendar ********************
        var calendarEl = document.getElementById('calendar'); //Reference calendar html element
        var calendar = new FullCalendar.Calendar(calendarEl, { //Constructor for calendar js object
          initialView: 'dayGridWeek', //Set to week view
          events: calendarEvents, //Set calendar js events to passed events list
          eventClick: function(info){ //Event listener definition: When an event is clicked, go to edit event page
            axios.get(edit_event_url, {params: {id: info?.event?.id}})
          }
        });
        calendar.render(); //Render the initialized calendar
        }

    app.drawProductivityBar = function (){
        //Time Marker
        const timeMarker = document.createElement('div');
        timeMarker.style= "position: absolute; width: 50px; min-height: 200px; margin: 0.5px; color: black; font-size: 12px;";
        //Single progress strip
        const intervalBar = document.createElement('div');
        intervalBar.style= "position: absolute; background: lime; width: 0.25px; min-height: 200px; margin: 0.5px; ";
        //Single Event
        const eventStrip = document.createElement('div');
        eventStrip.style = "position: relative; background: rgba(0,0,255,0.7); min-height: 200px; margin: 0.5px; border-radius: 5%; word-wrap: break-word; color: black;";
      
      
        
      
        //Current Date
        let curDate = new Date();
        curDate = curDate.getDate();
        
        //curDate = getFormattedDate(curDate); 
        //console.log(curDate);
        
        let curTime = new Date();
        curTime = ((curTime.getHours() * 60) + curTime.getMinutes()) / 1440;
      
        //Filter today's events
        //events = events.filter(event => getFormattedDate(event.start) == curDate);
        events = app.data.events.filter(event => (new Date(event.start)).getDate() == curDate);

        const productivityBar = document.getElementById("productivity-bar"); //Reference whole productivity bar
        //Add time increment lines
        productivityBar.innerHTML = "";
        //Add productivity strips
        for(let i=0;i<288;i++){
          //Time Markers
          if (i % 12 == 0){
            const newTimeMarker = timeMarker.cloneNode(true);
            newTimeMarker.innerHTML = (i/12) + "";
            newTimeMarker.style.left = ((i/288)*100) + "%";
            productivityBar.appendChild(newTimeMarker);
          }
          //Interval Strips
          let barColor = (i/288) >= curTime? "lime" : "red"; //decide block color
          const newIntervalBar = intervalBar.cloneNode(true); 
          
          newIntervalBar.style.background = barColor;
          newIntervalBar.style.left = ((i/288)*100) + "%";
          productivityBar.appendChild(newIntervalBar);
        }
        //Add event strips
        for(let i=0; i<events.length;i++){
          const newEventStrip = eventStrip.cloneNode(true); //Div for event strip
          //Event title text on strip
          newEventStrip.innerHTML = events[i]?.title; 
          //Event completion color
          console.log(events[i]?.completion_time)
          if(events[i]?.completion_time){
            newEventStrip.style.background = "rgba(170,255,0,0.5)"; 
          }
      
          //Calculate start time bar percentage
          let eventStartMins = new Date(events[i]?.start);
          if(eventStartMins !== null){
            eventStartMins = (eventStartMins.getHours() * 60) + eventStartMins.getMinutes();
            eventStartMins = eventStartMins / 1440;
          }
          //Calculate end time bar percentage
          let eventEndMins = new Date(events[i]?.end);
          //Get end of day Date
          let endOfDay = new Date();
          endOfDay.setHours(23);
          endOfDay.setMinutes(59);
          endOfDay.setSeconds(0);
          //Limit event bar to end of day
          eventEndMins = new Date(Math.min(eventEndMins, endOfDay));
          if(eventEndMins !== null){
            eventEndMins = (eventEndMins.getHours() * 60) + eventEndMins.getMinutes();
            eventEndMins = eventEndMins / 1440;
          }
          //Calculate strip width (event length)
          const stripWidth = eventEndMins - eventStartMins;
          //Calculate strip begin (start time)
          const stripBegin = eventStartMins * 100;
      
          //console.log(stripWidth*100);
          newEventStrip.style.position = "absolute";
          newEventStrip.style.width = (stripWidth*100) + "%";
          newEventStrip.style.left = stripBegin + "%";
          productivityBar.appendChild(newEventStrip);
        }
      }
    // **************************************************************************
    // ****************************** App Initialization Completion ******************************
    // **************************************************************************
    // This contains all the methods.
    app.methods = {
        get_events: app.get_events,
        set_completed_setting: app.set_completed_setting,
        set_completed: app.set_completed,
        drawCalendar: app.drawCalendar,
        drawProductivityBar: app.drawProductivityBar,
        calcProductivity: app.calcProductivity,
        get_productivity: app.get_productivity,
    };

    // This creates the Vue instance.
    app.vue = new Vue({
        el: "#vue-target",
        data: app.data,
        methods: app.methods
    });

    // And this initializes it.
    app.init = () => {
        // Put here any initialization code.
        app.get_events();
        app.calcProductivity();
    };
    // Call to the initializer.
    app.init();
};

// This takes the (empty) app object, and initializes it,
// putting all the code in it. 
init(app);
